//
//  SubmitBookingMeetingRoomHandle.h
//  EMeeting
//
//  Created by efutureinfo on 16/2/29.
//  Copyright © 2016年 itp. All rights reserved.
//

#import "BaseNetworkingHandle.h"
#import "FObjectModel.h"
#import "NetworkingManager.h"

@interface SubmitBookingMeetingRoomHandle : BaseNetworkingHandle

- (void)sendJSONRequestWithFObjectModel:(FObjectModel *)fObjectModel   Success:(void (^)(ResponseObject * response))success failure:(void (^)(NSError * error))failure;

@end
