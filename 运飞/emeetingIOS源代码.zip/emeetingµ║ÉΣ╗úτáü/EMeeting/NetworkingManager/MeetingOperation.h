//
//  MeetingOperation.h
//  EMeeting
//
//  Created by efutureinfo on 16/5/18.
//  Copyright © 2016年 itp. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "BaseNetworkingHandle.h"
#import "NetworkingManager.h"
@interface MeetingOperation : BaseNetworkingHandle
- (void)sendJSONRequestWithMeetingId:(NSString *) meetingId TermId:(NSString *) termId Number:(NSString *) number  OperationType:(NSString *) operationType  Type:(NSString *) type Success:(void (^)(ResponseObject * response))success failure:(void (^)(NSError * error))failure;
@end
