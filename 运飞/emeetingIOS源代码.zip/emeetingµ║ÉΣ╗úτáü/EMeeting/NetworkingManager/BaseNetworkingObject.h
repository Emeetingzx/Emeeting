//
//  BaseNetworkingObject.h
//  RedPacket
//
//  Created by itp on 15/10/30.
//  Copyright © 2015年 itp. All rights reserved.
//

#import <Foundation/Foundation.h>

#define NULLObject  ([NSNull null])
  
@interface BaseNetworkingObject : NSObject

- (id)initWithDictionary:(NSDictionary *)dict;

- (NSDictionary *)networkingDictionary;

@end

@interface NSArray (networking)

- (NSArray *)networkingArray;

@end

