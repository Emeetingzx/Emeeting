//
//  LogInViewController.h
//  RedPacket
//
//  Created by itp on 15/10/27.
//  Copyright © 2015年 itp. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LogInViewController : UIViewController

@end
