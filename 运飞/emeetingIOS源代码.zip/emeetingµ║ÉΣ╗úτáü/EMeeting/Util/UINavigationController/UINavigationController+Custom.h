//
//  UINavigationController+Custom.h
//  RedPacket
//
//  Created by itp on 15/12/10.
//  Copyright © 2015年 itp. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UINavigationController (Custom)

- (void)changeStackWithSencodViewController:(UIViewController *)viewcontroller;

@end
