//
//  FoodAndRefreshmentsInfo.m
//  EMeeting
//
//  Created by efutureinfo.cn on 16/2/23.
//  Copyright © 2016年 itp. All rights reserved.
//

#import "FoodAndRefreshmentsInfo.h"

@implementation FoodAndRefreshmentsInfo

-(instancetype)initWithDictionary:(NSDictionary *)dic{
    if (self=[super init]) {
        _addValueServiceId=dic[@"ID"]?:@"";
        _addValueServiceName=dic[@"AVSN"]?:@"";
        _addValueServicePath=dic[@"AVSP"]?:@"";
        _addValueServiceTime=dic[@"LUD"]?:@"";
        _isSelect=YES;
    }
    return self;
}

@end
