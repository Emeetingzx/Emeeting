//
//  FoodAndRefreshmentsInfo.h
//  EMeeting
//
//  Created by efutureinfo.cn on 16/2/23.
//  Copyright © 2016年 itp. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface FoodAndRefreshmentsInfo : NSObject
@property (strong ,nonatomic) NSString *addValueServiceId;
@property (strong ,nonatomic) NSString *addValueServiceName;
@property (strong ,nonatomic) NSString *addValueServicePath;
@property (strong ,nonatomic) NSString *addValueServiceTime;
@property (assign ,nonatomic) BOOL isSelect;
-(instancetype)initWithDictionary:(NSDictionary *)dic;
@end
