//
//  ReserveViewCellCollectionViewCell.m
//  EMeeting
//
//  Created by efutureinfo.cn on 16/2/22.
//  Copyright © 2016年 itp. All rights reserved.
//

#import "ReserveViewCellCollectionViewCell.h"

@implementation ReserveViewCellCollectionViewCell

- (void)awakeFromNib {
    // Initialization code
}

@end
