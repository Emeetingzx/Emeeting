//
//  ReserveViewCellCollectionViewCell.h
//  EMeeting
//
//  Created by efutureinfo.cn on 16/2/22.
//  Copyright © 2016年 itp. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ReserveViewCellCollectionViewCell : UICollectionViewCell
@property (weak, nonatomic) IBOutlet UILabel *addValueNameLabel;
@property (weak, nonatomic) IBOutlet UIImageView *selectedImage;
@property (weak, nonatomic) IBOutlet UIImageView *AddValueServiceImage;

@end
