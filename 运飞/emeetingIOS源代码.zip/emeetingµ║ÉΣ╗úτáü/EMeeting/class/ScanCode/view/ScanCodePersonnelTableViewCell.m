//
//  ScanCodePersonnelTableViewCell.m
//  EMeeting
//
//  Created by efutureinfo on 16/5/10.
//  Copyright © 2016年 itp. All rights reserved.
//

#import "ScanCodePersonnelTableViewCell.h"

@implementation ScanCodePersonnelTableViewCell

- (void)awakeFromNib {
    // Initialization code
    _headImage.layer.cornerRadius = 25;
    _headImage.layer.masksToBounds=YES;
   
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
