//
//  ScanCodePersonnelTableViewCell.h
//  EMeeting
//
//  Created by efutureinfo on 16/5/10.
//  Copyright © 2016年 itp. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ScanCodePersonnelTableViewCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UIImageView *headImage;
@property (weak, nonatomic) IBOutlet UILabel *name;
@property (weak, nonatomic) IBOutlet UILabel *meetingAttendanceNumber;
@property (weak, nonatomic) IBOutlet UILabel *scanCodeTime;
@end
