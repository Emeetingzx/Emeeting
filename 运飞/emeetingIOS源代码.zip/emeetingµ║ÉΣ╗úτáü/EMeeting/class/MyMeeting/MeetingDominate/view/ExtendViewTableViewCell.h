//
//  ExtendViewTableViewCell.h
//  EMeeting
//
//  Created by efutureinfo on 16/5/5.
//  Copyright © 2016年 itp. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ExtendViewTableViewCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *meetingRoomLable;
@property (weak, nonatomic) IBOutlet UILabel *timeLable;

@end
