//
//  AllMeetingCollectionReusableView.m
//  EMeeting
//
//  Created by efutureinfo.cn on 16/2/16.
//  Copyright © 2016年 itp. All rights reserved.
//

#import "AllMeetingCollectionReusableView.h"

@implementation AllMeetingCollectionReusableView

- (void)awakeFromNib {
    // Initialization code
}

@end
