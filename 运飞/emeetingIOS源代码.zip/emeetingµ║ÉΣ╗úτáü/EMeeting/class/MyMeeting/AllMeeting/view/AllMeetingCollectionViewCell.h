//
//  AllMeetingCollectionViewCell.h
//  EMeeting
//
//  Created by efutureinfo.cn on 16/2/16.
//  Copyright © 2016年 itp. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "RMCalendarModel.h"
@interface AllMeetingCollectionViewCell : UICollectionViewCell
@property(nonatomic, strong) RMCalendarModel *model;
@property (weak, nonatomic) IBOutlet UILabel *day;
@property (weak, nonatomic) IBOutlet UIImageView *bgImageView;

@end
