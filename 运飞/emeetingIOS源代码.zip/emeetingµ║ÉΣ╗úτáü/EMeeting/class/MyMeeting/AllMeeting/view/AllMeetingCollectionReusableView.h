//
//  AllMeetingCollectionReusableView.h
//  EMeeting
//
//  Created by efutureinfo.cn on 16/2/16.
//  Copyright © 2016年 itp. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AllMeetingCollectionReusableView : UICollectionReusableView
@property (weak, nonatomic) IBOutlet UILabel *month;

@end
