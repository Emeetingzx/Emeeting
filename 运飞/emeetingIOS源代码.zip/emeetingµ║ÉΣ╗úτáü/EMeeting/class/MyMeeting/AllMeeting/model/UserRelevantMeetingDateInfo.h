//
//  UserRelevantMeetingDateInfo.h
//  EMeeting
//
//  Created by efutureinfo.cn on 16/2/16.
//  Copyright © 2016年 itp. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface UserRelevantMeetingDateInfo : NSObject
@property (nonatomic, copy) NSString *meetingsDate;
@property (nonatomic, copy) NSString *theDayMettingNumber;

-(instancetype)initWithDictionary:(NSDictionary *)dic;
@end
