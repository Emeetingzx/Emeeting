//
//  MeetingProlong.h
//  EMeeting
//
//  Created by efutureinfo on 16/5/14.
//  Copyright © 2016年 itp. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "BaseNetworkingObject.h"
@interface MeetingProlong : BaseNetworkingObject
@property (nonatomic, copy) NSString *meetingRoomID;
@property (nonatomic, copy) NSString *isProlong;
@property (nonatomic, copy) NSString *prolongTime;
-(instancetype)initWithDictionary:(NSDictionary *)dic EndTime:(NSString *) endTime;
@end
