//
//  MeetingDetailsTableViewCell.m
//  EMeeting
//
//  Created by efutureinfo.cn on 16/2/3.
//  Copyright © 2016年 itp. All rights reserved.
//

#import "MeetingDetailsTableViewCell.h"

@implementation MeetingDetailsTableViewCell

- (void)awakeFromNib {
    // Initialization code
    
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
