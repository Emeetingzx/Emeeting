 //
//  PlaceTableViewCell.h
//  EMeeting
//
//  Created by efutureinfo.cn on 16/2/19.
//  Copyright © 2016年 itp. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PlaceTableViewCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UIButton *rescindBtn;
@property (weak, nonatomic) IBOutlet UILabel *placeLable;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *placeRight;

@end
