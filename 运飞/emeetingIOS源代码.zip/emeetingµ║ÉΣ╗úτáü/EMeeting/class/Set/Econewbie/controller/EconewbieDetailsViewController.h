//
//  EconewbieDetailsViewController.h
//  EMeeting
//
//  Created by efutureinfo.cn on 16/2/15.
//  Copyright © 2016年 itp. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface EconewbieDetailsViewController : UIViewController
@property (weak, nonatomic) IBOutlet UILabel *titleLable;
@property (weak, nonatomic) IBOutlet UITextView *textView;
@property (strong,nonatomic) NSString *titleString;
@property (strong,nonatomic) NSString *textString;
@end
