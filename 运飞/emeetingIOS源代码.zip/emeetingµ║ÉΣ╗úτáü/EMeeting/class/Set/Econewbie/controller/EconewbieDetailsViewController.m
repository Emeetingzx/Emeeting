//
//  EconewbieDetailsViewController.m
//  EMeeting
//
//  Created by efutureinfo.cn on 16/2/15.
//  Copyright © 2016年 itp. All rights reserved.
//

#import "EconewbieDetailsViewController.h"

@interface EconewbieDetailsViewController ()

@end

@implementation EconewbieDetailsViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    _textView.text=_textString;
    _titleLable.text=_titleString;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (IBAction)back:(id)sender {
    [self.navigationController popViewControllerAnimated:YES];

}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
