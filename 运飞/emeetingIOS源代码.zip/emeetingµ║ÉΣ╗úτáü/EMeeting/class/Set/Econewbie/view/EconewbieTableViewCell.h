//
//  EconewbieTableViewCell.h
//  EMeeting
//
//  Created by efutureinfo.cn on 16/2/2.
//  Copyright © 2016年 itp. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface EconewbieTableViewCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *titleLable;

@end
