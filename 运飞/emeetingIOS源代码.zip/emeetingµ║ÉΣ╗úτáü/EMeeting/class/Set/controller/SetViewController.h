//
//  SetViewController.h
//  EMeeting
//
//  Created by efutureinfo.cn on 16/2/2.
//  Copyright © 2016年 itp. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SetViewController : UITableViewController<UIAlertViewDelegate>
@property (weak, nonatomic) IBOutlet UILabel *versionNum;
@property (weak, nonatomic) IBOutlet UIImageView *versionImageView;

@end
