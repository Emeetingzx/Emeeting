//
//  DrawView.h
//  画图(下载实时状态)
//
//  Created by qianfeng on 15/9/5.
//  Copyright (c) 2015年 ljf. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DrawArcView : UIView

@property (nonatomic, assign) CGFloat percentValue;

@end
