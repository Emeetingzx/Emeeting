//
//  SubAreaTableViewCell.h
//  EMeeting
//
//  Created by efutureinfo on 16/2/2.
//  Copyright © 2016年 itp. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SubAreaTableViewCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *subAreaLabel;

@property (weak, nonatomic) IBOutlet UIImageView *selectImageView;

@end
