//
//  AddValueRegionInfo.m
//  EMeeting
//
//  Created by efutureinfo.cn on 16/2/24.
//  Copyright © 2016年 itp. All rights reserved.
//

#import "AddValueRegionInfo.h"

@implementation AddValueRegionInfo
-(instancetype)initWithDictionary:(NSDictionary *)dic{
    if (self=[super init]) {
        _addValueServiceRegionId=dic[@"ID"]?:@"";
        _addValueServiceRegionName=dic[@"AVSRN"]?:@"";
    }
    return self;
}

@end
