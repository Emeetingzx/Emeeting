//
//  serviceReserveData.m
//  EMeeting
//
//  Created by efutureinfo.cn on 16/2/24.
//  Copyright © 2016年 itp. All rights reserved.
//

#import "ServiceReserveData.h"

@implementation ServiceReserveData

@end
