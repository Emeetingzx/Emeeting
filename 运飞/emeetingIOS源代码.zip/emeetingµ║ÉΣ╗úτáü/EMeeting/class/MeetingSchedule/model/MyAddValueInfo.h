//
//  MyAddValueInfo.h
//  EMeeting
//
//  Created by efutureinfo.cn on 16/2/25.
//  Copyright © 2016年 itp. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "FoodAndRefreshmentsInfo.h"
@interface MyAddValueInfo : NSObject
@property (strong ,nonatomic) NSString *orderId;
@property (strong ,nonatomic) NSString *orderNumber;
@property (strong ,nonatomic) NSString *orderState;
@property (strong ,nonatomic) NSString *serviceAddress;
@property (strong ,nonatomic) NSString *serviceDate;
@property (strong ,nonatomic) NSArray<FoodAndRefreshmentsInfo *> *foodAndRefreshmentsInfoArr;
@property (strong ,nonatomic) NSString *actionItems;


-(instancetype)initWithDictionary:(NSDictionary *)dic;
@end
