//
//  MeetingRoomAddress.h
//  EMeeting
//
//  Created by efutureinfo on 16/2/24.
//  Copyright © 2016年 itp. All rights reserved.
//

#import "BaseNetworkingObject.h"

@interface MeetingRoomAddress : BaseNetworkingObject

@property (nonatomic, copy) NSString *iD;
@property (nonatomic, copy) NSString *pID;
@property (nonatomic, copy) NSString *addessChinese;
@property (nonatomic, copy) NSString *orderID;
@property (nonatomic, copy) NSString *levelId;
@property (nonatomic, copy) NSString *isValidId;
@property (nonatomic, copy) NSString *longAddessChinese;

@end
