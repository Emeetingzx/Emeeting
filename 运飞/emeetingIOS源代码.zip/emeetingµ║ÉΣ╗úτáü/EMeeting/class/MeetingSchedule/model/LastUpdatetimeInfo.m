//
//  LastUpdatetimeInfo.m
//  EMeeting
//
//  Created by efutureinfo on 16/2/24.
//  Copyright © 2016年 itp. All rights reserved.
//

#import "LastUpdatetimeInfo.h"

@implementation LastUpdatetimeInfo

@end
