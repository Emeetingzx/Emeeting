//
//  serviceReserveData.h
//  EMeeting
//
//  Created by efutureinfo.cn on 16/2/24.
//  Copyright © 2016年 itp. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ServiceReserveData : NSObject
@property (strong ,nonatomic) NSString *serviceDate;
@property (strong ,nonatomic) NSString *serviceRegionID;
@property (strong ,nonatomic) NSString *serviceAddress;
@property (strong ,nonatomic) NSString *phone;
@property (strong ,nonatomic) NSString *foodIds;

@end
