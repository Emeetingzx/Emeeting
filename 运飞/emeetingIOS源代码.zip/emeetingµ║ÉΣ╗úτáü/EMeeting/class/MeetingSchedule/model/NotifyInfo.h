//
//  NotifyInfo.h
//  EMeeting
//
//  Created by efutureinfo on 16/5/27.
//  Copyright © 2016年 itp. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NotifyInfo : NSObject
@property (nonatomic, copy) NSString *notifyType;

@property (nonatomic, copy) NSString *meetingID;

@property (nonatomic, copy) NSString *notifyContent;

@property (nonatomic, copy) NSString *meetingNotifyType;
@property (nonatomic, copy) NSString *meetingType;
@property (nonatomic, copy) NSString *valueErverNotifyType;
-(instancetype)initWithDictionary:(NSDictionary *)dic;
@end
