//
//  LastUpdatetimeInfo.h
//  EMeeting
//
//  Created by efutureinfo on 16/2/24.
//  Copyright © 2016年 itp. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface LastUpdatetimeInfo : NSObject

@property (nonatomic, copy) NSString *name;

@property (nonatomic, copy) NSString *lDT;

@end
