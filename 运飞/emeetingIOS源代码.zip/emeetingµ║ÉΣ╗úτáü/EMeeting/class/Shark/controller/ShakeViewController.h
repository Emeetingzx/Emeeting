//
//  ShakeViewController.h
//  EMeeting
//
//  Created by efutureinfo on 16/1/29.
//  Copyright © 2016年 itp. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ShakeViewController : UIViewController

@property (weak, nonatomic) IBOutlet UIButton *headImage;

@property (assign, nonatomic) BOOL isFromFirst;

@end
